files = dir('*.mat');

% Original workstation path removed; set the working directory to the required data folder before running.

fid = fopen('./sceneid.txt','w')

fprintf(fid, ['EXP_VERS','\t','SUBJECT','\t','Scene','\t','TRIAL_ID\r'])

for i = 1:length(files)
    load(files(i).name)
    for j = 1:104
        fprintf(fid, ['Experiment 1', '\t', 'exp1-asy-', files(i).name(13:15), '\t', experimentStruc.images{j,1}, '\t', num2str(j),'\r'])
        experimentStruc.images(1)
    end
end

% Original workstation path removed; set the working directory to the required data folder before running.
files = dir('*.mat');
for i = 1:length(files)
    load(files(i).name)
    for j = 1:104
        fprintf(fid, ['Experiment 2', '\t', 'exp2-asy-', files(i).name(13:14), '\t', experimentStruc.images{j,1}, '\t', num2str(j),'\r'])
        experimentStruc.images(1)
    end
end
