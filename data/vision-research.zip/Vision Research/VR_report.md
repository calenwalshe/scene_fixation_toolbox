Luminance study publication plots
========================================================




=======


```
## Error: cannot change working directory
```





####Basic data quality verifications




###Adding Scene ID



#### Participant Data




#### Hypothesis: Shifting luminance down results in increased fixation durations, shifting luminance up results in decreased fixation durations. 
## Analysis notes. This analysis is a post-hoc constructed baseline. The baseline measure is the fixation duration immediately preceding a luminance shift. 
![plot of chunk asymmetrical](figure/asymmetrical1.png) 

```
## [1] "Statistical results from Experiment 1"
```

```
## Linear mixed model fit by REML ['lmerMod']
## Formula: NEXT_FIX_DUR ~ SHIFT_DIRECTION + (1 + SHIFT_DIRECTION | SUBJECT) 
##    Data: subset(manipulate_only, EXP_VERS == "Experiment 1") 
## 
## REML criterion at convergence: 184159 
## 
## Random effects:
##  Groups   Name                Variance Std.Dev. Corr       
##  SUBJECT  (Intercept)          1769.8   42.07              
##           SHIFT_DIRECTIONUP      19.5    4.41   -1.00      
##           SHIFT_DIRECTIONDOWN   562.7   23.72    0.29 -0.29
##  Residual                     25554.6  159.86              
## Number of obs: 14174, groups: SUBJECT, 22
## 
## Fixed effects:
##                     Estimate Std. Error t value
## (Intercept)           297.21       9.14    32.5
## SHIFT_DIRECTIONUP      12.67       3.56     3.6
## SHIFT_DIRECTIONDOWN    44.66       6.16     7.2
## 
## Correlation of Fixed Effects:
##                  (Intr) SHIFT_DIRECTIONU
## SHIFT_DIRECTIONU -0.353                 
## SHIFT_DIRECTIOND  0.181  0.077
```

```
## Linear mixed model fit by REML ['lmerMod']
## Formula: NEXT_FIX_DUR ~ SHIFT_DIRECTION + (1 + SHIFT_DIRECTION | SUBJECT) +      (1 + SHIFT_DIRECTION | Scene) 
##    Data: subset(manipulate_only, EXP_VERS == "Experiment 1") 
## 
## REML criterion at convergence: 184153 
## 
## Random effects:
##  Groups   Name                Variance Std.Dev. Corr       
##  Scene    (Intercept)             0      0.0               
##           SHIFT_DIRECTIONUP     644     25.4     NaN       
##           SHIFT_DIRECTIONDOWN   550     23.4     NaN  0.58 
##  SUBJECT  (Intercept)          1893     43.5               
##           SHIFT_DIRECTIONUP     158     12.6    -0.43      
##           SHIFT_DIRECTIONDOWN   758     27.5     0.22 -0.51
##  Residual                     25341    159.2               
## Number of obs: 14174, groups: Scene, 100; SUBJECT, 22
## 
## Fixed effects:
##                     Estimate Std. Error t value
## (Intercept)           297.22       9.44   31.49
## SHIFT_DIRECTIONUP      13.46       5.05    2.67
## SHIFT_DIRECTIONDOWN    45.14       7.23    6.24
## 
## Correlation of Fixed Effects:
##                  (Intr) SHIFT_DIRECTIONU
## SHIFT_DIRECTIONU -0.286                 
## SHIFT_DIRECTIOND  0.129 -0.044
```

```
## [1] "Statistical results from Experiment 2"
```

```
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
```

![plot of chunk asymmetrical](figure/asymmetrical2.png) 

```
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
```

```
## pdf 
##   2
```

```
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
## ymax not defined: adjusting position using y instead
```

```
## pdf 
##   2
```




```r
print((xtable(as.data.frame(coef(summary(lmer_exp1))))), type = "html")
```

<!-- html table generated in R 3.0.2 by xtable 1.7-1 package -->
<!-- Thu Jun  5 10:27:29 2014 -->
<TABLE border=1>
<TR> <TH>  </TH> <TH> Estimate </TH> <TH> Std. Error </TH> <TH> t value </TH>  </TR>
  <TR> <TD align="right"> (Intercept) </TD> <TD align="right"> 297.21 </TD> <TD align="right"> 9.14 </TD> <TD align="right"> 32.53 </TD> </TR>
  <TR> <TD align="right"> SHIFT_DIRECTIONUP </TD> <TD align="right"> 12.67 </TD> <TD align="right"> 3.56 </TD> <TD align="right"> 3.56 </TD> </TR>
  <TR> <TD align="right"> SHIFT_DIRECTIONDOWN </TD> <TD align="right"> 44.66 </TD> <TD align="right"> 6.16 </TD> <TD align="right"> 7.25 </TD> </TR>
   </TABLE>







![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots1.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots2.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots3.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots4.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots5.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots6.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots7.png) ![plot of chunk Empirical & GAM Plots](figure/Empirical___GAM_Plots8.png) 

